# Bidirectional-static-looping-linked-list
双向静态循环链表
7．设计双向静态循环链表类模板 
仿照教材中带头结点的双向循环链表类模板，设计带头结点的双向静态循环链表类模板，并实现相
应的成员函数。
