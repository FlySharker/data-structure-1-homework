#pragma once
#include<bits/stdc++.h>
using namespace std;

template <class T>
class SeqList
{
protected:
	int length;
	int maxLength;
	T* elems;
public:
	SeqList(int size = 0);
	SeqList(T v[], int n, int size = 0);
	virtual ~SeqList();
	void FreeList();
	//int GetLength() const;
	//bool IsEmpty() const;
	void Clear();
	void Print();
	int LocateElem(const T& e);
	int GetElem(int i, T& e);
	int SetElem(int i, const T& e);
	int DeleteElem(int i, T& e);
	void InsertElem(int i, const T& e);
	void InsertElem(const T& e);
	void insertelem(const T& e);
	int Max();
	int Min();
	void deleteRange(const T& s, const T& t);
	void Merge(const SeqList<T>& sa, SeqList<T>& sr);
	SeqList(const SeqList<T>& sa);
	SeqList<T>& operator=(const SeqList<T>& sa);
};

template <class T>
SeqList<T>::SeqList(int size)
{
	elems = new T[size];
	maxLength = size;
	length = 0;
}

template <class T>
SeqList<T>::SeqList(T v[], int n, int size)
{
	elems = new T[size];
	maxLength = size;
	length = n;
	for (int i = 0; i < n; i++) {
		elems[i] = v[i];
	}
}

template <class T>
SeqList<T>::~SeqList()
{
	FreeList();
}

template <class T>
void SeqList<T>::FreeList()
{
	delete[]elems;
}

template <class T>
void SeqList<T>::Clear()
{
	length = 0;
}

template <class T>
int SeqList<T>::LocateElem(const T& e)
{
	int i = 0;
	while (i < length && elems[i] != e) {
		i++;
	}
	return i < length ? i + 1 : 0;
}

template <class T>
int SeqList<T>::GetElem(int i, T& e) 
{
	try
	{
		if (i<1 || i>length) throw(int)0;
	}
	catch (int)
	{
		cout << "λ�ò�����" << endl;
		return 0;
	}
	e = elems[i - 1];
	return 1;
}

template <class T>
int SeqList<T>::SetElem(int i, const T& e)
{
	try
	{
		if (i<1 || i>length) throw(int)0;
	}
	catch (int)
	{
		cout << "λ�ò�����" << endl;
		return 0;
	}
	elems[i - 1] = e;
	return 0;
}

template <class T>
int SeqList<T>::DeleteElem(int i, T& e)
{
	try
	{
		if (i<1 || i>length) throw(int)0;
	}
	catch (int)
	{
		cout << "λ�ò�����" << endl;
		return 0;
	}
	e = elems[i - 1];
	for (int j = i; j < length; j++) {
		elems[j - 1] = elems[j];
	}
	length--;
	return 0;
}

template <class T>
void SeqList<T>::deleteRange(const T& s, const T& t)
{
	int m=0, n=0;
	sort(elems, elems + length);
	try
	{
		if (s>=t) throw(int)0;
	}
	catch (int)
	{
		cout << "ֵ������" << endl;
		return;
	}
	for (int i = 0; i < length; i++) {
		if (elems[i] >= s) {
			m = i;
			break;
		}
	}
	for (int j = length-1; j > 0; j--) {
		if (elems[j] <= t) {
			n = j;
			break;
		}
	}
	for (int k = n + 1; k < length; k++) {
		elems[m + k - n - 1] = elems[k];
	}
	length = length - (n - m + 1);
}

template <class T>
void SeqList<T>::InsertElem(int i, const T& e)
{
	try
	{
		if (length==maxLength) throw(int)0;
		if (i<1 || i>length) throw(char)0;
	}
	catch (int)
	{
		cout << "˳�������" << endl;
	}
	catch (char)
	{
		cout << "λ�ò�����" << endl;
	}
	for (int j = length; j >= i; j--) {
		elems[j] = elems[j - 1];
	}
	elems[i - 1] = e;
	length++;
}

template <class T>
void SeqList<T>::InsertElem(const T& e)
{
	try
	{
		if (length == maxLength) throw(int)0;
	}
	catch (int)
	{
		cout << "˳�������" << endl;
	}
	elems[length] = e;
	length++;
}

template <class T>
void SeqList<T>::insertelem(const T& e)
{
	sort(elems, elems + length);
	if (e < elems[0]) {
		for (int i = length-1; i >=0 ; i--) {
			elems[i + 1] = elems[i];
		}
		elems[0] = e;
		length++;
		return;
	}
	else if (e > elems[length - 1]) {
		InsertElem(e);
		return;
	}
	for (int i = 0; i < length-1; i++) {
		if (e >= elems[i] && e <= elems[i + 1]) {
			for (int j = length ; j >= i+2; j--) {
				elems[j] = elems[j-1];
			}
			elems[i+1] = e;
			length++;
			break;
		}
	}
}

template <class T>
SeqList<T>::SeqList(const SeqList<T>& sa)
{
	*this = sa;
}

template <class T>
SeqList<T>& SeqList<T>::operator=(const SeqList<T>& sa)
{
	if (this == &sa) return *this;					
	FreeList();
	int r = sa.length;
	int t = sa.maxLength;
	elems = new T[t];
	length = r;
	maxLength = t;
	for (int i = 0; i < r; i++) {
		elems[i] = sa.elems[i];
	}
	return *this;
}

template <class T>
void SeqList<T>::Print()
{
	for (int i = 0; i < length; i++) {
		cout << elems[i] << " ";
	}
	cout << endl;
}

template <class T>
int SeqList<T>::Max()
{
	int m = -1;
	for (int i = 0; i < length; i++) {
		m = max(m, elems[i]);
	}
	return m;
}

template <class T>
int SeqList<T>::Min()
{
	int mm = 100000;
	for (int i = 0; i < length; i++) {
		mm = min(mm, elems[i]);
	}
	return mm;
}

template <class T>
void SeqList<T>::Merge(const SeqList<T>& sa,  SeqList<T>& s3)
{
	int n = maxLength + sa.maxLength;
	s3.elems = new T[n];
	s3.maxLength = n;
	for (int i = 0; i < length; i++) {
		s3.elems[i] = elems[i];
	}
	for (int j = length; j < length + sa.length; j++) {
		s3.elems[j] = sa.elems[j - length];
	}
	s3.length = length + sa.length;
	sort(s3.elems, s3.elems + length + sa.length);
}